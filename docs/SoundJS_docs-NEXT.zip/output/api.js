YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "EventDispatcher",
        "FlashPlugin",
        "HTMLAudioLoader",
        "HTMLAudioPlugin",
        "Listener",
        "SoundChannel",
        "SoundInstance",
        "SoundJS",
        "SoundLoader",
        "TagPool",
        "WebAudioLoader",
        "WebAudioPlugin"
    ],
    "modules": [
        "SoundJS"
    ],
    "allModules": [
        {
            "displayName": "SoundJS",
            "name": "SoundJS"
        }
    ]
} };
});