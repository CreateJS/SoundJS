YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "EventDispatcher",
        "FlashPlugin",
        "HTMLAudioPlugin",
        "Listener",
        "SoundChannel",
        "SoundInstance",
        "SoundJS",
        "WebAudioPlugin"
    ],
    "modules": [
        "CreateJS",
        "SoundJS"
    ],
    "allModules": [
        {
            "displayName": "CreateJS",
            "name": "CreateJS"
        },
        {
            "displayName": "SoundJS",
            "name": "SoundJS",
            "description": "The SoundJS library manages the playback of audio on the web. It works via plugins which abstract the actual audio\nimplementation, so playback is possible on any platform without specific knowledge of what mechanisms are necessary\nto play sounds.\n\nBy default, the Web Audio and HTML plugins are used (when available), although developers can change plugin priority\nor add new plugins (such as the provided {{#crossLink \"FlashPlugin\"}}{{/crossLink}}). Please see the SoundJS API\nmethods for more on the playback and plugin APIs. To install plugins, or specify a different plugin order, see\n{{#crossLink \"SoundJS/installPlugins\"}}{{/crossLink}}.\n\nBefore you can play a sound, it must be registered. You can do this with the {{#crossLink \"SoundJS/createInstance\"}}{{/crossLink}}\nmethod. If you use <a href=\"http://preloadjs.com\" target=\"_blank\">PreloadJS</a>, this is handled for you when the\nsound is preloaded.\n\nTo play a sound, use the {{#crossLink \"SoundJS/play\"}}{{/crossLink}} method. When sounds are played, SoundJS returns\ninstances which can be paused, resumed, muted, etc. Please see the {{#crossLink \"SoundInstance\"}}{{/crossLink}}\ndocumentation for more on the instance control APIs."
        }
    ]
} };
});